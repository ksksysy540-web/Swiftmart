import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import Image from "next/image"
import { Star, ShoppingCart, Search, Filter, X } from "lucide-react"
import { ScrollButton } from "@/components/scroll-button"
import { AnimatedLogo } from "@/components/animated-logo"
import { HeroSlider } from "@/components/hero-slider"

export default async function Home() {
  const supabase = createClient()

  // Fetch products from database
  const { data: products, error } = await supabase
    .from("products")
    .select("*")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products:", error)
  }

  const featuredProduct = products?.[0]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <AnimatedLogo />
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href="/auth/login">Sign In</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <HeroSlider />

      {/* Featured Product */}
      {featuredProduct && (
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="mb-4 bg-accent text-accent-foreground">Featured Product</Badge>
                <h2 className="text-4xl font-bold mb-4">{featuredProduct.product_name}</h2>
                <p className="text-lg text-muted-foreground mb-6">{featuredProduct.description}</p>
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="ml-2 text-sm text-muted-foreground">(2,847 reviews)</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 mb-8">
                  <span className="text-3xl font-bold text-primary">${featuredProduct.price}</span>
                  <Badge variant="destructive">Only 3 Left!</Badge>
                </div>
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
                  <Link href={featuredProduct.affiliate_link || "#"} target="_blank">
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Buy Now - Limited Stock!
                  </Link>
                </Button>
              </div>
              <div className="relative">
                <Image
                  src={featuredProduct.image_url || "/placeholder.svg?height=400&width=400"}
                  alt={featuredProduct.product_name}
                  width={400}
                  height={400}
                  className="rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Products Grid with Filter System */}
      <section id="products" className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Our Best Sellers</h2>
            <p className="text-lg text-muted-foreground">Discover products that our customers love most</p>
          </div>

          <div className="mb-8 bg-white rounded-lg p-6 shadow-sm border">
            <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
              {/* Search Bar */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>

              {/* Filter Buttons */}
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
                  All Products
                </Button>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Electronics
                </Button>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Fashion
                </Button>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Beauty
                </Button>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Home & Garden
                </Button>
              </div>

              {/* Sort Dropdown */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort by:</span>
                <select className="border border-input rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                  <option>Featured</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Newest</option>
                  <option>Best Selling</option>
                  <option>Customer Rating</option>
                </select>
              </div>
            </div>

            {/* Active Filters */}
            <div className="flex items-center gap-2 mt-4 pt-4 border-t">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              <Badge variant="secondary" className="flex items-center gap-1">
                All Products
                <X className="w-3 h-3 cursor-pointer" />
              </Badge>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products?.map((product) => (
              <div
                key={product.id}
                className="bg-card rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="relative">
                  <Image
                    src={product.image_url || "/placeholder.svg?height=250&width=250"}
                    alt={product.product_name}
                    width={250}
                    height={250}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2 flex flex-col gap-1">
                    {product.badges?.map((badge: string, index: number) => (
                      <Badge
                        key={index}
                        className={`text-xs ${
                          badge === "Best Seller"
                            ? "bg-yellow-500 text-yellow-50"
                            : badge === "Trending"
                              ? "bg-red-500 text-red-50"
                              : badge === "Limited Offer"
                                ? "bg-orange-500 text-orange-50"
                                : badge === "New Arrival"
                                  ? "bg-green-500 text-green-50"
                                  : "bg-accent text-accent-foreground"
                        }`}
                      >
                        {badge}
                      </Badge>
                    )) || <Badge className="bg-accent text-accent-foreground">Hot Deal!</Badge>}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2 line-clamp-2">{product.product_name}</h3>
                  <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{product.description}</p>
                  <div className="flex items-center mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="ml-2 text-sm text-muted-foreground">(4.8)</span>
                  </div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-primary">${product.price}</span>
                    <Badge variant="destructive" className="text-xs">
                      Limited Stock
                    </Badge>
                  </div>
                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
                    <Link href={`/product/${product.id}`}>View Details</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Experience Premium Quality?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of satisfied customers today!</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <ScrollButton
              targetId="products"
              size="lg"
              variant="secondary"
              className="bg-white text-primary hover:bg-white/90"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              Start Shopping Now
            </ScrollButton>
            <ScrollButton
              targetId="products"
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-primary bg-transparent"
            >
              View All Products
            </ScrollButton>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground mb-4">© 2024 SwiftMart. All rights reserved.</p>
          <p className="text-sm text-muted-foreground">
            30-day money-back guarantee • Free shipping on orders over $50 • 24/7 customer support
          </p>
        </div>
      </footer>
    </div>
  )
}
